classdef Bases < handle   
    methods(Static)
        % Carrega a base iris
        function iris = loadIris()
            fprintf('\nLoading iris dataset... ');
            base  = load('iris.dat');
            X = base(:,1:4);
            Y = base(:,5);
            if min(Y) == 0
                Y = Y+1;
            end    
            X = X-mean(X);
            X = X/max(X(:));              
            
            iris.X = X; 
            iris.Y = Y;
            iris.samples_per_classe = sum(Y==unique(Y)',1);
            
            fprintf('done!\n');
        end
        % Carrega a base glass
        function glass = loadGlass()     
            fprintf('\nLoading glass dataset... ');
            base = load('bases/glass/glass.dat');
            X = base(:,2:10);
            Y = base(:,11);            
            for i=1:numel(Y)
                if(Y(i)>4)
                    Y(i)=Y(i)-1;
                end
            end            
            X = X-mean(X);
            X = X/max(X(:));                           
            
            glass.X = X; 
            glass.Y = Y;
            glass.samples_per_classe = sum(Y==unique(Y)',1);
            
            fprintf('done!\n');
        end
        
        % Carrega base de dados de sinais de libras
        function libras = loadLibras()
            fprintf('\nLoading libras dataset... ');
            base = load('bases/libras/libras.mat');
            X = base.DATA';
            Y = base.labels';
            if min(Y) == 0
                Y = Y+1;
            end                 
            X = X-mean(X);
            X = X/max(X(:));                                   
            
            libras.X = X; 
            libras.Y = Y; 
            libras.samples_per_classe = sum(Y==unique(Y)',1);
            
            fprintf('done!\n');
        end
        % Carrega base de dados de poses do corpo
        function body = loadBodyPoses()
            fprintf('\nLoading body poses dataset... ');
            base = load('bases/body/posedb.txt');        
            X = base(:,[1:4 7:10 13]);            
            Y = base(:,14);                         
                        
            X = X-mean(X);
            X = X/max(X(:));                                           
                       
            body.X = X;     
            body.Y = Y;                                                                    
            body.samples_per_classe = sum(Y==unique(Y)',1);                                    
            
            fprintf('done!\n');  
        end   
        
        % Carrega a base MNIST
        function mnist = loadMNIST(NUM_SAMPLES)
            fprintf('\nLoading mnist dataset... ');
            currfolder = pwd;
            cd bases/mnist/;
            [imgs,labels] = readMNIST('train-images.idx3-ubyte','train-labels.idx1-ubyte',NUM_SAMPLES,0);
            X = reshape(imgs,[],NUM_SAMPLES)';
            Y = labels+1;
            X = X-mean(X);
            X = X/max(X(:));
            mnist.X = X; mnist.Y = Y;
            cd(currfolder);
            fprintf('done!\n');
        end
    end    
end

