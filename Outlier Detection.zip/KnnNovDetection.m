classdef KnnNovDetection < handle
    properties          
        X = [];                 % Pontos X [n_points x dim]
        Y = [];                 % R�tulos Y                
        n_classes = 0;          % N�meros de classes
        untrained_classes = 0;  % N�mero de classes n�o treinadas                
        knn_arg = 0;            % O mesmo que o par�metro K do artigo
        knn_threshold = 0;      % O mesmo que o par�metroe "kappa" do artigo                
        n_thresholds = 0;       % N�mero de threshold "tau"
        threshold = [];         % Vetor de thresholds "tau" (o melhor deve ser encontrado)                
        training_ratio = 0;     % Taxa de treinamento de amostras
        split = {};             % Guarda um objeto split para auxiliar o processo de valida��o
        samples_per_classe = 0; % Amostras por classe
    end
    
    methods
        % Construtor.
        function obj = KnnNovDetection(X,Y,knn_arg,knn_threshold,n_classes,untrained_classes,training_ratio)
            obj.X = X;
            obj.Y = Y;
            obj.knn_arg = knn_arg;
            obj.knn_threshold = knn_threshold;
            obj.n_classes = n_classes;   
            obj.training_ratio = 0.7;
            if nargin>=6
                obj.untrained_classes = untrained_classes;
                if nargin==7
                    obj.training_ratio = training_ratio;
                end                 
            end 
            % C�digo inclu�do ---------------------------------------------
            obj.samples_per_classe = sum(Y==unique(Y)',1);            
            [obj.samples_per_classe,id] = sort(obj.samples_per_classe,'descend');
            obj.samples_per_classe = cat(1,id,obj.samples_per_classe);
            % -------------------------------------------------------------             
        end
        
        % Executa experimentos de detec��o de novidade e busca de hiperpar�metros
        function experiment = runNoveltyDetectionExperiments(obj,n_experiments,view_plot_metric)
            split_exp = cell(n_experiments,1);
            
            MCC = zeros(n_experiments,obj.n_thresholds);
            AFR = zeros(n_experiments,obj.n_thresholds);
            F1 = zeros(n_experiments,obj.n_thresholds);
            TPR = zeros(n_experiments,obj.n_thresholds);
            TNR = zeros(n_experiments,obj.n_thresholds);
            FPR = zeros(n_experiments,obj.n_thresholds);            
            FNR = zeros(n_experiments,obj.n_thresholds);            
            
            evaluations = cell(n_experiments,obj.n_thresholds);
                    
            classes_id = 1:obj.n_classes;
            random_select_classes = true;
            for i=1:n_experiments
                rng(i);
                % Seleciona classes treinadas e n�o treinadas
                if random_select_classes                    
                    [trained,untrained,is_trained_class] = Split.selectClasses(obj.n_classes,obj.untrained_classes);
                else
                    % Classe n�o treinada
                    classe_unt = rem(i-1,obj.n_classes)+1; 
                    
                    is_trained_class = true(1,obj.n_classes);
                    is_trained_class(classe_unt) = false;
                    
                    trained =  classes_id(classes_id ~= classe_unt);
                    untrained =  classes_id(classes_id == classe_unt);
                end
                
                % Divide os �ndices em treino e teste
                [idx_train,idx_test] = Split.trainTestIdx(obj.X,obj.Y,obj.training_ratio,obj.n_classes,is_trained_class);
                [xtrain,xtest,ytrain,ytest] = Split.dataTrainTest(idx_train,idx_test,obj.X,obj.Y);                
                
                % Todas as amostras n�o treinadas s�o definidas
                % como outliers (label -1)
                ytest(logical(sum(ytest==untrained,2))) = -1;
                
                RT = [];
                for j=1:obj.n_thresholds
                    fprintf('\nKNN (K=%d kappa=%d) \tTest %d/%d \tThreshold %d/%d\n',obj.knn_arg,obj.knn_threshold,i,n_experiments,j,obj.n_thresholds);                   
                    evaluations{i,j} = obj.evaluate(xtrain,ytrain,xtest,ytest,obj.threshold(j));
                    MCC(i,j) = evaluations{i,j}.MCC;
                    F1(i,j) = evaluations{i,j}.F1;
                    AFR(i,j) = evaluations{i,j}.AFR;
                    TPR(i,j) = evaluations{i,j}.TPR;
                    TNR(i,j) = evaluations{i,j}.TNR;
                    FPR(i,j) = evaluations{i,j}.FPR;                    
                    FNR(i,j) = evaluations{i,j}.FNR;
                    if view_plot_metric
                        RT = cat(1,RT,MCC(i,j));
                        figure(1);
                        clf('reset');                        
                        plot(obj.threshold(1:j),RT,'-','LineWidth',3);
                        xlim([obj.threshold(1),obj.threshold(end)]);
                        ylim([0,1]);      
                        xlabel('Threshold');
                        ylabel('Matthews correlation coefficient (MCC)');
                        title(['KNN [ test ',num2str(i),'/',num2str(n_experiments),' | threshold ',num2str(j),'/',num2str(obj.n_thresholds),' ]']);
                        drawnow;
                        pause(0.01);
                    end
                end
                split_exp{i}.trained_classes = trained; 
                split_exp{i}.untrained_classes = untrained;
                split_exp{i}.idx_train = idx_train; 
                split_exp{i}.idx_test = idx_test;
                split_exp{i}.xtrain = xtrain; 
                split_exp{i}.xtest = xtest;
                split_exp{i}.ytrain = ytrain; 
                split_exp{i}.ytest = ytest;
            end
            close all;
            % M�trica MCC
            mean_mcc = mean(MCC,1);
            [~,best_threshold_id] = max(mean_mcc);
            
            % Demais m�tricas
            mean_f1 = mean(F1,1);
            mean_afr = mean(AFR,1);
            mean_tpr = mean(TPR,1);
            mean_tnr = mean(TNR,1);
            mean_fpr = mean(FPR,1);
            mean_fnr = mean(FNR,1);
            
            all_metrics.MCC = MCC;
            all_metrics.F1 = F1;
            all_metrics.AFR = AFR;
            all_metrics.TPR = TPR;
            all_metrics.TNR = TNR;
            all_metrics.FPR = FPR;
            all_metrics.FNR = FNR;
            experiment.all_metrics = all_metrics;
            
            model.training_ratio = obj.training_ratio;
            model.best_threshold_id = best_threshold_id;
            model.threshold = obj.threshold(best_threshold_id);
            model.untrained_classes = obj.untrained_classes;
            model.knn_arg = obj.knn_arg;
            model.knn_threshold = obj.knn_threshold;            
            
            experiment.model = model;
            experiment.split = cell2mat(split_exp);
            experiment.evaluations = evaluations;
            experiment.mean_mcc = mean_mcc;
            experiment.mean_f1 = mean_f1;
            experiment.mean_afr = mean_afr;
            experiment.mean_tpr = mean_tpr;
            experiment.mean_tnr = mean_tnr;
            experiment.mean_fpr = mean_fpr;
            experiment.mean_fnr = mean_fnr;
            
            experiment.mcc_score = mean_mcc(best_threshold_id);
            experiment.f1_score = mean_f1(best_threshold_id);
            experiment.afr_score = mean_afr(best_threshold_id);
            experiment.tpr_score = mean_tpr(best_threshold_id);
            experiment.tnr_score = mean_tnr(best_threshold_id);
            experiment.fpr_score = mean_fpr(best_threshold_id);
            experiment.fnr_score = mean_fnr(best_threshold_id);
            
            fprintf('\nRESULTS\n MCC Score: %.4f\n F1 Score: %.4f\n AFR Score: %.4f\n',...
                    experiment.mcc_score,experiment.f1_score,experiment.afr_score);            
                           
           figure; plot(obj.threshold,mean_mcc);
           xlim([obj.threshold(1),obj.threshold(end)]);
           xlabel('threshold'); ylabel('mcc'); title('MCC');
                      
           figure; plot(obj.threshold,mean_afr);
           xlim([obj.threshold(1),obj.threshold(end)]);
           xlabel('threshold'); ylabel('afr'); title('AFR');
        end                
        
        % Valida��o do algoritmo knn nov detection
        function model = validation(obj,n_validations,view_plot_error)            
            obj.split = cell(n_validations,1);
            mcc = zeros(n_validations,obj.n_thresholds);            
            for i=1:n_validations
                rng(i);
                % Cria um objeto split. Particiona a base em dois conjuntos
                % de classes treinadas e n�o treinadas. Separa uma 
                % parte para treinamento e outra para teste              
                obj.split{i} = SplitData(obj.X,obj.Y,obj.training_ratio,obj.untrained_classes);                
                % Separa uma parte do treinamento para valida��o                
                [id_train,id_val] = obj.split{i}.idTrainVal();
                [xtrain,ytrain,xval,yval] = obj.split{i}.dataTrainVal(id_train,id_val);                
                RT = [];
                for j=1:obj.n_thresholds
                    fprintf('\nKNN (K=%d kappa=%d) \tVal %d/%d \tThreshold %d/%d\n',obj.knn_arg,obj.knn_threshold,i,n_validations,j,obj.n_thresholds);                   
                    result = obj.evaluate(xtrain,ytrain,xval,yval,obj.threshold(j));
                    mcc(i,j) = result.MCC;
                    if view_plot_error
                        RT = cat(1,RT,mcc(i,j));
                        figure(1);
                        clf('reset');                        
                        plot(obj.threshold(1:j),RT,'-','LineWidth',3);
                        xlim([obj.threshold(1),obj.threshold(end)]);
                        ylim([0,1]);      
                        xlabel('Threshold');
                        ylabel('Matthews correlation coefficient (MCC)');
                        title(['KNN [ valida��o ',num2str(i),'/',num2str(n_validations),' | threshold ',num2str(j),'/',num2str(obj.n_thresholds),' ]']);
                        drawnow;
                        pause(0.01);
                    end
                end
                model.split{i} = obj.split{i};
            end
            close all;
            mean_mcc = mean(mcc,1);             
            [max_mean_mcc,ID] = max(mean_mcc);            
            
            model.training_ratio = obj.training_ratio;
            model.threshold = obj.threshold(ID);
            model.untrained_classes = obj.untrained_classes;
            model.knn_arg = obj.knn_arg;
            model.knn_threshold = obj.knn_threshold;
            model.mean_mcc = max_mean_mcc;            
        end
                
        % Avalia o modelo treinado
        function [results,evaluations] = evaluateModel(obj,model,n_tests)
            evaluations = cell(n_tests,1);
            for i=1:n_tests
                rng(i);
                fprintf('\nKNN (K=%d kappa=%d) \tTest: %d/%d\n',obj.knn_arg,obj.knn_threshold,i,n_tests);                               
                id_test = obj.split{i}.idTest();
                [xtest,ytest] = obj.split{i}.dataTest(id_test);               
                [xtrain,ytrain] = obj.split{i}.dataTrain(obj.split{i}.id_train_val_t);
                evaluations{i} = obj.evaluate(xtrain,ytrain,xtest,ytest,model.threshold);
            end
            results = struct2table(cell2mat(evaluations));
        end
        
        % Avalia o modelo treinado em conjuntos de testes
        function [results,evaluations] = evaluateTests(obj,xtrain,ytrain,xtest,ytest,model)
            n_tests = size(xtest,3);
            evaluations = cell(n_tests,1);
            for i=1:n_tests
                fprintf('\nKNN (K=%d kappa=%d) \tTest: %d/%d\n',obj.knn_arg,obj.knn_threshold,i,n_tests);
                evaluations{i} = obj.evaluate(xtrain,ytrain,xtest(:,:,i),ytest,model.threshold);
            end
            results = struct2table(cell2mat(evaluations));
        end
        
        % Avalia o knn nov detection 
        function result = evaluate(obj,xtrain,ytrain,xtest,ytest,threshold)            
            % Predi��o
            predictions = obj.predict(xtrain,ytrain,xtest,threshold);

            % Report outliers
            outlier_gt = -ones(size(ytest));
            outlier_gt(ytest>0) = 1;
            
            outlier_predictions = -ones(size(predictions));
            outlier_predictions(predictions>0) = 1;            
            
            report_outliers = ClassificationReport(outlier_gt,outlier_predictions);

            % General report
            report = ClassificationReport(ytest,predictions);            
            
            result.threshold =  threshold;
            result.predictions = predictions;
            result.outlier_predictions = outlier_predictions;
            result.TPR = report_outliers.TPR(2);
            result.TNR = report_outliers.TNR(2);
            result.FPR = report_outliers.FPR(2); 
            result.FNR = report_outliers.FNR(2);
            result.F1 = report_outliers.F1(2);
            result.MCC = report_outliers.MCC(2);
            result.ACC = report_outliers.ACC(2);
            result.AFR = report_outliers.AFR(2);
            result.general_conf_matrix = report.CM;
            result.outlier_conf_matrix = report_outliers.CM;     
            
            fprintf('\nthreshold: %f \nTPR: %f \nTNR: %f \nFPR: %f \nFNR: %f \nF1: %f \nMCC: %f \nACC: %f\nAFR: %f\n',threshold,report_outliers.TPR(2),report_outliers.TNR(2),report_outliers.FPR(2),report_outliers.FNR(2),report_outliers.F1(2),report_outliers.MCC(2),report_outliers.ACC(2),report_outliers.AFR(2));
        end
        
        % Predi��o
        function predictions = predict(obj,xtrain,ytrain,xtest,threshold)
            [epsilonvec,means,medians,stds,iqrs,maxs] =  obj.computeEpsilons(xtrain,ytrain);
            %epsilonvec =  medians + threshold * iqrs;
            %epsilonvec =  means + threshold * stds;
            epsilonvec =  threshold * epsilonvec;
            
            NTe = size(xtest,1);
                                                 
            predictions = zeros(NTe,1);           
            
            full_kdtree = KDTreeSearcher(xtrain);                      
            classes_kdtree = cell(obj.n_classes,1);                        
                        
            % Divide as amostras de treino por classes
            xtrainpart = cell(obj.n_classes,1);
            counterclass = zeros(obj.n_classes,1);
            for c=1:obj.n_classes                
                xtrainpart{c}.X = xtrain(ytrain==c,:);
                xtrainpart{c}.n = size(xtrainpart{c}.X,1);
                counterclass(c) = xtrainpart{c}.n;
            end            
                        
            % Cria k-trees por classe
            for c=1:obj.n_classes
                if xtrainpart{c}.n==0
                    continue;
                end
                classes_kdtree{c} = KDTreeSearcher(xtrainpart{c}.X);
            end
            
            % Avalia��o no teste com epsilons
            for i=1:NTe
                % Testa se o exemplo i � outlier
                isoutlier = true;
                for c=1:obj.n_classes
                    if xtrainpart{c}.n == 0
                        continue;
                    end
                    [~,d] = knnsearch(classes_kdtree{c},xtest(i,:),'k',obj.knn_arg);                                        
                    % N�mero de vizinhos suficientemente pr�ximos
                    n_nearest_neighbor = sum(d<epsilonvec(c));
                    if n_nearest_neighbor >= obj.knn_threshold
                        isoutlier = false;
                        break;
                    end
                end
                
                if(isoutlier)                    
                    predictions(i) = -1;
                else % Inlier

                    % Classifica o exemplo
                    tryK = obj.knn_arg;
                    while true
                        [n,d] = knnsearch(full_kdtree,xtest(i,:),'k',tryK); % busca os K mais pr�ximos de cada ponto xtest_i
                        
                        % Classes dos K vizinhos mais pr�ximos
                        yvec = ytrain(n); 
                        
                        % Seleciona vizinhos mais pr�ximos v�lidos                        
                        valid_nearest_neighbor = false(numel(yvec),1);
                        for k=1:numel(d)
                            if d(k) < epsilonvec(yvec(k))
                                valid_nearest_neighbor(k) = true;
                            end
                        end                        
                        n_valid_nearest_neighbor = sum(valid_nearest_neighbor);
                          
                        % Se o exemplo de teste n�o foi considerado
                        % outlier por�m ficou com uma quantidade de vizinhos
                        % mais pr�ximos inferior a K tente buscar 2*K
                        % vizinhos mais pr�ximos e repita o processo...
                        if n_valid_nearest_neighbor < obj.knn_arg
                            % se o vizinho mais distante dista mais que os
                            % epsilons de todas as classes, ent�o pare de
                            % dobrar o tryK
                            if d(end) > max(epsilonvec) || tryK >= size(xtrain,1)
                                yvec = yvec(valid_nearest_neighbor);                                
                                break;                                
                            else
                                tryK = 2*tryK;                            
                            end
                        else
                            yvec = yvec(valid_nearest_neighbor);
                            break;
                        end
                    end
                    predictions(i) = mode(yvec);
                end
            end
        end
        
        % Calcula os epsilons por classe.
        function [epsilonvec,means,medians,stds,iqrs,maxs] = computeEpsilons(obj,xtrain,ytrain)
            NTr=size(xtrain,1);

            means = zeros(obj.n_classes,1);
            medians = zeros(obj.n_classes,1);
            iqrs = zeros(obj.n_classes,1);
            stds = zeros(obj.n_classes,1);
            maxs = zeros(obj.n_classes,1);
            epsilonvec = zeros(obj.n_classes,1);         
                        
            full_kdtree = KDTreeSearcher(xtrain);

            classes_kdtree = cell(obj.n_classes,1);
            xtrainpart = cell(obj.n_classes,1);
            dim = size(xtrain,2);

            % DIVIDINDO PARTIC�ES
            for c=1:obj.n_classes
                xtrainpart{c}.n = 0;
            end
            for i=1:NTr
                xtrainpart{ytrain(i)}.n = xtrainpart{ytrain(i)}.n + 1;
            end           
            for c=1:obj.n_classes
                xtrainpart{c}.X = zeros(xtrainpart{c}.n,dim);
            end
            counterclass = zeros(obj.n_classes,1);
            for i=1:NTr
                label = ytrain(i);
                counterclass(label) = counterclass(label) + 1;
                xtrainpart{label}.X(counterclass(label),:) = xtrain(i,:);
            end

            % CRIANDO KDTREES POR LABEL
            for c=1:obj.n_classes
                if xtrainpart{c}.n==0
                    continue;
                end
                classes_kdtree{c} = KDTreeSearcher(xtrainpart{c}.X);
            end

            % CALCULANDO EPSILONS
            kdistsperclass = zeros(obj.n_classes,NTr);
            for c=1:obj.n_classes
                if xtrainpart{c}.n == 0
                    continue;
                end
                count = 0;
                for i=1:xtrainpart{c}.n
                    [n,d] = knnsearch(classes_kdtree{c},xtrainpart{c}.X(i,:),'k',obj.knn_arg+1);
                    count = count + 1;
                    kdistsperclass(c,count) = d(end);
                end
                dists = kdistsperclass(c,1:count);
                epsilonvec(c) = (mean(dists) + std(dists));
                means(c) = mean(dists);
                medians(c) = median(dists);
                iqrs(c) = iqr(dists);
                stds(c) = std(dists);
                maxs(c) = max(dists);
            end            
        end       
    end    
end
