%% INICIALIZA��ES
clc; clear; close all;
run('libraries/lmnn/setpaths3.m');
addpath('libraries/kpca');
addpath('libraries/knfst');

% Varia��o da quantidade de dados de treinamento
%N = [250,500,1000,2500,5000,10000];
N = [1000];
for i=1:numel(N)
    if N(i) == 1000
        %DIM = [10,50,100,250,500,750,1000,2500,5000];
        DIM = [5000,7500,10000];
    else
        DIM = 10;
    end
    for j=1:numel(DIM)
        %% CRIA A BASE      
        base = Simulations.gaussianDistributions(N(i),DIM(j));
        X = base.X;
        y = base.y;
        xtrain = base.xtrain;
        ytrain = base.ytrain;

        out_dir = strcat('simulation_4/N=',int2str(N(i)),' DIM=',int2str(DIM(j)));

        n_classes = numel(unique(y));
        max_std = max(std(X));

        % M�TODOS
        methods = {'knn','lmnn','klmnn','knfst','one_svm','multi_svm','kpca'};

        search_parameters = true;        

        if search_parameters
            % CALIBRA��O DOS PAR�METROS POR FOR�A BRUTA
            n_experiments = 5;
            untrained_classes = 1;
            
            view_plot_metric = false;

            % Para KNN, LMNN e KLMNN
            K = 3;
            kappa = 1;

            % Define intervalos de busca de par�metros de kernel e thresholds
            % KNN
            knn_par.n_thresholds = 20;
            knn_par.threshold = linspace(0.01,4.5,knn_par.n_thresholds)';

            % LMNN
            lmnn_par.n_thresholds = 20;
            lmnn_par.threshold = linspace(0.01,4.5,lmnn_par.n_thresholds)';

            % KLMNN
            klmnn_par.n_thresholds = 20;
            klmnn_par.threshold = linspace(0.01,4.5,klmnn_par.n_thresholds)';
            klmnn_par.n_kernels = 10;
            klmnn_par.kernel_type = 'gauss';
            klmnn_par.kernel = linspace(max_std,2.5*max_std,klmnn_par.n_kernels)';

            % KNFST
            knfst_par.n_thresholds = 20;
            knfst_par.threshold = linspace(0.01,0.7,knfst_par.n_thresholds)';
            knfst_par.kernel_type = 'gauss';
            knfst_par.n_kernels = 10;
            knfst_par.kernel = linspace(0.5*max_std,2.5*max_std,knfst_par.n_kernels)';

            % ONE SVM
            one_svm_par.kernel_type = 'gauss';
            one_svm_par.n_kernels = 20;
            one_svm_par.kernel = linspace(0.5*max_std,2.5*max_std,one_svm_par.n_kernels)';

            % MULTI SVM
            multi_svm_par.n_thresholds = 20;
            multi_svm_par.threshold = linspace(0.0,1.0,multi_svm_par.n_thresholds)';
            multi_svm_par.kernel_type = 'gauss';
            multi_svm_par.n_kernels = 10;
            multi_svm_par.kernel = linspace(0.5*max_std,2.5*max_std,multi_svm_par.n_kernels)';

            % KPCA
            kpca_par.n_thresholds = 20;
            kpca_par.threshold = linspace(0.5,1.0,kpca_par.n_thresholds)';
            kpca_par.kernel_type = 'gauss';
            kpca_par.n_kernels = 10;
            kpca_par.kernel = linspace(0.5*max_std,2.5*max_std,kpca_par.n_kernels)';

            parameters = {knn_par,lmnn_par,klmnn_par,knfst_par,one_svm_par,multi_svm_par,kpca_par};

            % Valida��o dos m�todos (Usa 70% dos dados da base)
            Methods.runValidations(X,y,methods(1),parameters,out_dir,n_experiments,...
                                   n_classes,untrained_classes,K,kappa,view_plot_metric);
                               
            % Avalia os m�todos em um conjunto de teste qualquer e salva as m�tricas de acur�cia
            Methods.runEvaluationModels(methods(1),out_dir,n_experiments,K,kappa);                               
        else
            % TESTA COM PAR�METROS MANUAIS
            % Para KNN, LMNN e KLMNN
            K = 3;
            kappa = 1;

            % KNN
            knn_par.threshold_arg = 1;

            % LMNN
            lmnn_par.threshold_arg = 1;

            % KLMNN
            klmnn_par.threshold_arg = 1.0;    
            klmnn_par.kernel_type = 'gauss'; % ou 'poly';
            klmnn_par.kernel_arg = 0.5;

            % KNFST
            knfst_par.threshold_arg = 1;
            knfst_par.kernel_type = 'gauss';
            knfst_par.kernel_arg = 0.5;

            % ONE SVM
            one_svm_par.kernel_type = 'gauss';
            one_svm_par.kernel_arg = 0.5;

            % MULTI SVM
            multi_svm_par.threshold_arg = 0.5;
            multi_svm_par.kernel_type = 'gauss';    
            multi_svm_par.kernel_arg = 0.5;

            % KPCA NOV   
            kpca_par.threshold_arg = 0.2;
            kpca_par.kernel_type = 'gauss';
            kpca_par.kernel_arg = 0.5;

            parameters = {knn_par,lmnn_par,klmnn_par,knfst_par,one_svm_par,multi_svm_par,kpca_par};

            % Avalia os m�todos
            Methods.runEvaluationsParameter(xtrain,ytrain,X,y,methods([1,2,3,4,5,6,7]),parameters,out_dir,n_classes,K,kappa);
        end
        
    end
end                        